import { Cart } from "../components/cart/cart";

const Basket = ( { convertPrice, cart, setCart, checkList, setCheckList } ) => {
  return <Cart cart={cart} setCart={setCart} convertPrice={convertPrice} checkList={checkList} setCheckList={setCheckList}  />;
};

export default Basket;
