import { useState } from "react";
import styles from "./cart.module.css";
import { CartHeader } from "./cartHeader";
import { CartList } from "./cartList";
import { TotalCart } from "./totalCart";

export const Cart = ({ cart, setCart, convertPrice, checkList, setCheckList }) => {

  const [total, setTotal] = useState(0); // 가격을 계산하기 위한 변수

  const handleAllCheck = (checked) => {
      if(checked){
          const checkItem = [];
          cart.map( (cart) => checkItem.push(cart.id)); // checkItem배열에 장바구니에 있는 모든 상품이 들어간다.
          setCheckList(checkItem);  // 모두 선택이 됨.
      }else{
        setCheckList([]); // setCheckList를 빈 배열로 만들어 모두 선택해제되게 한다.
      }
  }

  const handleCheckList = (checked, id) => {
    if (checked) {
      setCheckList([...checkList, id]);
    } else {
      setCheckList(checkList.filter((check) => check !== id));
    }
  };

  const handleRemove = (id) => {
    setCart(cart.filter((el) => el.id !== id)); // id랑 같은 것을 제외한 모든 것을 보존. 즉, id상품은 삭제하면서 새로운 setCart로 새로운 장바구니를 생성.
    setCheckList(checkList.filter((checked) => checked !== id));
  };

  const handleQuantity = (type, id, quantity) => {
    const found = cart.filter((el) => el.id === id)[0];
    const idx = cart.indexOf(found);
    const cartItem = {
      id: found.id,
      image: found.image,
      name: found.name,
      price: found.price,
      provider: found.provider,
      quantity: quantity,
    };

    if (type === "plus") {
      setCart([...cart.slice(0, idx), cartItem, ...cart.slice(idx + 1)]);
    } else {
      if (quantity === 0) return;
      setCart([...cart.slice(0, idx), cartItem, ...cart.slice(idx + 1)]);
    }
  };

  //console.log(checkList);

  const isAllChecked = cart.length === checkList.length && checkList.length !== 0;

  const found = checkList.map( (checkList) => cart.filter( (el) => el.id ===  checkList)  );

  return (
    <>
      <header className={styles.header}>
        <h1>장바구니</h1>
      </header>

      <CartHeader handleAllCheck={handleAllCheck} isAllChecked={isAllChecked} />

      {cart.length === 0 ? (
        <div className={styles.not}>
          <h2>장바구니에 담긴 상품이 없습니다.</h2>
          <p>원하시는 상품을 장바구니에 담아보세요..</p>
        </div>
      ) : (
        cart.map((cart) => {
          // 장바구니에 있는 상품의 개수만큼 map을 이용하여 같은 이미지이기는 하지만 <CartList />를 만든다.
          return (
            <CartList
              key={`key-${cart.id}`}
              cart={cart}
              setCart={setCart} 
              convertPrice={convertPrice}
              handleQuantity={handleQuantity}
              handleRemove={handleRemove}
              handleCheckList={handleCheckList}
              checkList={checkList}
            />
          ); // 헤더 오른쪽 상단의 장바구니 카트 아이콘을 눌러 장바구니 안에 내용에서 선택한 상품이 제대로 보여주도록함.
        })
      )}

      {cart.length === 0 ? "" : <TotalCart total={total} setTotal={setTotal} cart={cart} found={found} convertPrice={convertPrice}/>}
    </>
  );
};
