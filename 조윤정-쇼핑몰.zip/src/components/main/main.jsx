import styles from "./main.module.css";
import { EventBanner } from "../eventBanner/eventBanner";
import { Product } from "../products/product";
import { useEffect } from "react";
import axios from "axios";

export const Main = ( {products, setProducts, convertPrice } ) => {

  useEffect( () => {
      axios.get("/data/products.json").then( (data) => {
          // console.log(data);
          setProducts(data.data.products);
      });
  }, [setProducts]);

  //console.log(products);

  const sortProduct = (type) => {
    const newProduct = [...products];

    if(type === "recent"){
      newProduct.sort((a,b) => a.id - b.id);  //기존에 있는 id 두개를 비교하야 오름차순 정렬을 함
      setProducts(newProduct);
    }else if(type === "low"){
      newProduct.sort((a,b) => a.price - b.price);  //기존에 있는 price 두개를 비교하야 오름차순 정렬을 함
      setProducts(newProduct);
    } else {
      newProduct.sort((a,b) => b.price - a.price);  //기존에 있는 price 두개를 비교하야 내림차순 정렬을 함
      setProducts(newProduct);
    }
  }
  return (
    <>
      <EventBanner />
      <div className={styles.filter}>
        <p onClick={() => sortProduct("recent")}>최신순</p> {/*recent*/}
        <p onClick={() => sortProduct("low")}>낮은 가격</p> {/*low*/}
        <p onClick={() => sortProduct("high")}>높은 가격</p> {/*high*/}
      </div>
      <main className={styles.flex_wrap}>
        { products.map( (product) => {
              return <Product key={`key-${product.id}`} product={product}  convertPrice={convertPrice} />
        }) }
      </main>
    </>
  );
};
