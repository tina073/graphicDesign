import { useParams } from "react-router-dom";
import styles from "./detail.module.css";
import { useEffect, useState } from "react";
import axios from "axios";

export const Detail = ( { convertPrice, cart, setCart } ) => {
  const {id} = useParams();
  const [product, setProduct] = useState({});
  const [count, setCount] = useState(1);
  
  const handleQuantity = (type) => {
      if ( type === "plus" ) {
          setCount(count+1);
      } else {
        if ( count === 1 ) return;  // 수량이 기본값 1일 때 마이너스 버튼을 눌러 0이하로 되는 것을 방지
        setCount(count-1);
      }
  }

  useEffect( () => {
      axios.get("/data/products.json").then(
        (data) => { setProduct(data.data.products.find((product) => product.id === parseInt(id)));
      });
  }, [id]);
  //console.log(product);

  const setQuantity = ( id, quantity) => {  // 기존 장바구니에 있는 상품일 경우 지금 선택한 상품의 id와 장바구니에 들어있는 같은 id의 상품 수량만 증가시키는 함수
      const found = cart.filter(( el ) => el.id === id )[0]; // 장바구니에 있는 상품의 id와 기존에 있는  id가 같다면 

      const idx = cart.indexOf(found);
      const cartItem = {  // 선택한 상품과 동일한 상품의 정보를 모두 가지고 옴.
          id: product.id,
          name: product.name,
          provider: product.provider,
          price: product.price,
          image: product.image,
          quantity:quantity,
      } 
      setCart([...cart.slice(0, idx), cartItem, ...cart.slice(idx + 1)]);
      // slice(시작 인덱스번호, 끝나는 인덱스번호-1)
  }

  const handleCart = () => {  // 장바구니에 없는 상품을 추가하는 함수
      const cartItem = {
        id: product.id,
        name: product.name,
        provider: product.provider,
        price: product.price,
        image: product.image,
        quantity:count,
      }

      const found = cart.find( (el) => el.id === cartItem.id ); // 같은 id를 찾아서 found 넣는다

      if (found){
        setQuantity( cartItem.id, found.quantity + count ); // 동일한 상품의 기존 수량에 새롭게 추가되는 같은 상품의 수량을 추가
      }else{
        setCart([...cart, cartItem]); // cartItem만 setCart에 넣어주면 현재 선택한 상품 하나만 들어가기 때문에 기존에 있는 상품들을 유지하면서 함께 표시하기 위해 ...cart를 앞에 쓴다.
      }
      
  }

  console.log(cart);

  return (
    product && (
    <>
      <main className={styles.main}>
        <section className={styles.product}>
          <div className={styles.product_img}>
            <img src={product.image} alt="product" />
          </div>
        </section>
        <section className={styles.product}>
          <div className={styles.product_info}>
            <p className={styles.seller_store}>{product.provider}</p>
            <p className={styles.product_name}>{product.name}</p>
            <span className={styles.price}>
            {convertPrice(product.price + "")}
              <span className={styles.unit}>원</span>
            </span>
          </div>

          <div className={styles.delivery}>
            <p>택배배송 / 무료배송</p>
          </div>

          <div className={styles.line}></div>

          <div className={styles.amount}>
            <img
              className={styles.minus}
              src="/images/icon-minus-line.svg"
              alt="minus"
              onClick={ () => handleQuantity("minus")}
            />

            <div className={styles.count}>
              <span>{count}</span>
            </div>

            <img
              className={styles.plus}
              src="/images/icon-plus-line.svg"
              alt="plus"
              onClick={ () => handleQuantity("plus")}
            />
          </div>

          <div className={styles.line}></div>

          <div className={styles.sum}>
            <div>
              <span className={styles.sum_price}>총 상품 금액</span>
            </div>

            <div className={styles.total_info}>
              <span className={styles.total}>
                총 수량 <span className={styles.total_count}>{count}개</span>
              </span>
              <span className={styles.total_price}>
                {convertPrice(product.price * count)}  {/* 현재 상품의 가격과 개수를 곱하여 총 금액을 표시 */}
                <span className={styles.total_unit}>원</span>
              </span>
            </div>
          </div>

          <div className={styles.btn}>
            <button className={styles.btn_buy}>바로 구매</button>
            <button className={styles.btn_cart} onClick={ () => handleCart() }>장바구니</button>
          </div>
        </section>
      </main>
    </>
    )
  );
};
